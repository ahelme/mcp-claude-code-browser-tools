# ⛔ MCP SERVER DIRECTORY - READ-ONLY ZONE ⛔

## 🚨 **CRITICAL WARNING FOR ALL CLAUDE SESSIONS** 🚨

**THIS DIRECTORY AND ALL ITS FILES ARE STRICTLY READ-ONLY**

### **❌ DO NOT MODIFY:**
- `server.mjs` - MCP server implementation
- `http-bridge.mjs` - HTTP bridge server
- `package.json` - Dependencies
- `start.sh` - Startup scripts
- Any other files in this directory

### **🛡️ WHY THIS RULE EXISTS:**
1. **Stability** - These files provide stable infrastructure for multiple projects
2. **Dependencies** - Other projects and users depend on this stable API
3. **Testing** - Changes require careful coordination and testing
4. **Maintenance** - Updates need proper version control and documentation

### **⚠️ IF YOU NEED CHANGES:**
1. **STOP** - Do not make changes
2. **DOCUMENT** - Create a GitHub issue explaining what you need
3. **DISCUSS** - Get user approval before any modifications
4. **COORDINATE** - Plan changes with proper testing

### **✅ WHAT YOU CAN DO:**
- **Read** files to understand functionality
- **Debug** by examining code and logs
- **Create issues** for needed improvements
- **Work in** `/chrome-extension/` directory instead

### **🔧 FOR DEBUGGING:**
- Use HTTP bridge logs: Check server output
- Test HTTP endpoints: `curl http://localhost:3024/health`
- Check Chrome extension: Browser DevTools console
- Use integration tests: `chrome-extension/integration-test.js`

### **📝 REMEMBER:**
**All browser tools functionality should be implemented in `/chrome-extension/` not here!**

---

## **🎯 PREVIOUS VIOLATIONS TO LEARN FROM:**

**Date**: 2025-09-25
**Violation**: Modified `server.mjs` with request ID tracking and enhanced logging
**Issue**: Broke established READ-ONLY rule
**Resolution**: Changes reverted, this warning file created
**Lesson**: Debug features belong in chrome-extension, not MCP server

---

**⚡ IF YOU ARE READING THIS AND ABOUT TO MODIFY FILES - STOP! ⚡**

**Remember: Chrome extension functionality goes in `/chrome-extension/` directory**